from multiprocessing.connection import Client as cli
import cv2 as cv
import base64

adrr = ('localhost',12345)
conn = cli(adrr, authkey=b'bsg')

vid = cv.VideoCapture(1)
while vid.isOpened():
        _,frame = vid.read()
        # encoded,buffer = cv.imencode('.jpg',frame,[cv.IMWRITE_JPEG_QUALITY,80])
        # message = base64.b64encode(buffer)
        conn.send(frame)
        cv.waitKey(1)

# adrr = ('0.0.0.0',12345)
# conn = cli(adrr, authkey=b'bsg')

# adrr1 = ('0.0.0.0',12340)
# conn1 = cli(adrr, authkey=b'bs')


# def update(capture,connn):
#     while True:
#         _,frame = capture.read()
#         encoded,buffer = cv.imencode('.jpg',frame,[cv.IMWRITE_JPEG_QUALITY,80])
#         message = base64.b64encode(buffer)
#         connn.send(message)


# vid = cv.VideoCapture(0)
# vid1 = cv.VideoCapture(1)

# t1 = Thread(target=update, args=(vid,conn))
# t2 = Thread(target=update, args=(vid1,conn1))

# t1.start()
# t2.start()

        
